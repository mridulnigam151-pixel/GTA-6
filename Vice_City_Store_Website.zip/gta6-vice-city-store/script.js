const products = [
  {id:1,name:"After Hours Graphic Tee",category:"apparel",price:999,image:"after_hours_graphic_tee_hero_1.png",tag:"NEW DROP",desc:"Statement streetwear"},
  {id:2,name:"Miami Nights Hoodie",category:"apparel",price:1499,image:"mockup1_miami_nights_hoodie_1.png",tag:"BESTSELLER",desc:"Everyday heavyweight style"},
  {id:3,name:"Vice Snapback Cap",category:"caps",price:799,image:"mockup1_vice_snapback_cap_1.png",tag:"LIMITED",desc:"Adjustable streetwear cap"},
  {id:4,name:"Ocean Drive Shirt",category:"apparel",price:1199,image:"mockup1_ocean_drive_shirt_1.png",tag:"NEW",desc:"Tropical-inspired shirt"},
  {id:5,name:"Coastal Route Tote",category:"accessories",price:599,image:"coastal_route_tote_lifestyle_1.png",tag:"",desc:"Carry your essentials"},
  {id:6,name:"Vice City Drinking Glass",category:"accessories",price:499,image:"vice_city_drinking_glass_product_crop_1.png",tag:"",desc:"Collectible glassware"},
  {id:7,name:"PS5 DualSense Controller",category:"gaming",price:5999,image:"collage2_dualsense_controller_card_1.png",tag:"GAMING GEAR",desc:"Console accessory concept"},
  {id:8,name:"PS5 Charging Station",category:"gaming",price:2499,image:"mockup1_ps5_charging_station_1.png",tag:"GAMING GEAR",desc:"Keep controllers powered"},
  {id:9,name:"Vice City Keychain & Pen",category:"accessories",price:299,image:"vice_city_keychain_and_pen_crop_1.png",tag:"",desc:"Small details, big energy"},
  {id:10,name:"Vice Nights Zip Hoodie",category:"apparel",price:1699,image:"vice_nights_zip_hoodie_lifestyle_1.png",tag:"",desc:"Zip-up graphic hoodie"},
  {id:11,name:"Ocean Drive Snapback",category:"caps",price:799,image:"new_drop_ocean_drive_cap_card_photo_1.png",tag:"FRESH DROP",desc:"Classic curved brim"},
  {id:12,name:"Neon Controller Skin",category:"gaming",price:699,image:"mockup1_neon_controller_skin_1.png",tag:"GAMING GEAR",desc:"Colourful controller look"}
];
const money = n => "₹" + Number(n).toLocaleString("en-IN");
const grid = document.getElementById("product-grid");
const related = document.getElementById("related-grid");
let cart = JSON.parse(localStorage.getItem("viceCityCart") || "[]");
let selectedPlan = {hours:1,price:199};

function productCard(p){
  return `<article class="product-card">
    <a class="product-image" href="#shop"><img loading="lazy" src="assets/${p.image}" alt="${p.name}">${p.tag?`<span class="product-tag">${p.tag}</span>`:""}</a>
    <div class="product-details"><h3>${p.name}</h3><p>${p.desc}</p>
      <div class="product-bottom"><strong class="product-price">${money(p.price)}</strong><button class="add-btn" data-add="${p.id}">ADD TO CART +</button></div>
    </div></article>`;
}
function renderProducts(filter="all"){
  const list = filter==="all" ? products : products.filter(p=>p.category===filter);
  grid.innerHTML = list.map(productCard).join("");
  related.innerHTML = products.slice(0,4).map(productCard).join("");
}
function saveCart(){localStorage.setItem("viceCityCart",JSON.stringify(cart));renderCart();}
function addToCart(id){
  const p=products.find(x=>x.id===id);const item=cart.find(x=>x.id===id);
  if(item)item.qty++;else cart.push({...p,qty:1});saveCart();showToast(`${p.name} added to cart`);
}
function renderCart(){
  document.getElementById("cart-count").textContent=cart.reduce((s,p)=>s+p.qty,0);
  const host=document.getElementById("cart-items");
  if(!cart.length){host.innerHTML='<p class="empty-cart">Your cart is waiting for a little Vice City energy.</p>';}
  else host.innerHTML=cart.map(p=>`<div class="cart-row"><img src="assets/${p.image}" alt=""><div><b>${p.name}</b><small>${p.qty} × ${money(p.price)}</small></div><button class="remove-item" data-remove="${p.id}" aria-label="Remove ${p.name}">×</button></div>`).join("");
  document.getElementById("cart-total").textContent=money(cart.reduce((s,p)=>s+p.price*p.qty,0));
}
function showToast(message){const t=document.getElementById("toast");t.textContent=message;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2300)}
function openOverlay(id){document.getElementById(id).classList.add("open");document.body.style.overflow="hidden"}
function closeOverlay(id){document.getElementById(id).classList.remove("open");document.body.style.overflow=""}

document.addEventListener("click",e=>{
  const add=e.target.closest("[data-add]");if(add){addToCart(Number(add.dataset.add));return;}
  const remove=e.target.closest("[data-remove]");if(remove){cart=cart.filter(p=>p.id!==Number(remove.dataset.remove));saveCart();return;}
  const close=e.target.closest("[data-close]");if(close){closeOverlay(close.dataset.close);return;}
  const filter=e.target.closest("[data-filter]");if(filter){document.querySelectorAll(".filter-chip").forEach(b=>b.classList.remove("selected"));filter.classList.add("selected");renderProducts(filter.dataset.filter);}
});
document.getElementById("cart-open").addEventListener("click",()=>openOverlay("cart-overlay"));
document.querySelectorAll(".overlay").forEach(o=>o.addEventListener("click",e=>{if(e.target===o)closeOverlay(o.id)}));
document.getElementById("checkout-btn").addEventListener("click",()=>showToast("Demo only — connect WooCommerce or a payment backend for checkout."));
document.querySelectorAll(".plan").forEach(btn=>btn.addEventListener("click",()=>{
  document.querySelectorAll(".plan").forEach(b=>b.classList.remove("selected"));btn.classList.add("selected");
  selectedPlan={hours:Number(btn.dataset.hours),price:Number(btn.dataset.price)};
  document.getElementById("rental-price").textContent=money(selectedPlan.price);
  document.getElementById("booking-plan-summary").textContent=`${selectedPlan.hours} hour${selectedPlan.hours>1?"s":""} · ${money(selectedPlan.price)}`;
}));
document.getElementById("book-now").addEventListener("click",()=>{document.getElementById("booking-plan-summary").textContent=`${selectedPlan.hours} hour${selectedPlan.hours>1?"s":""} · ${money(selectedPlan.price)}`;openOverlay("booking-overlay")});
document.getElementById("booking-date").min=new Date().toISOString().split("T")[0];
document.getElementById("booking-form").addEventListener("submit",e=>{
  e.preventDefault();const data=Object.fromEntries(new FormData(e.target).entries());
  const ref="VC"+Math.random().toString(36).slice(2,8).toUpperCase();
  document.getElementById("booking-message").textContent=`Request ${ref} created in this demo. ${data.name}, your ${selectedPlan.hours}-hour request is ready for backend integration.`;
  e.target.reset();showToast("Booking request captured in this demo.");
});
document.getElementById("newsletter-form").addEventListener("submit",e=>{e.preventDefault();document.getElementById("newsletter-message").textContent="Thanks for signing up! Connect an email marketing service to collect subscribers.";e.target.reset()});
document.querySelector(".menu-toggle").addEventListener("click",()=>{const n=document.querySelector(".main-nav");n.classList.toggle("open");document.querySelector(".menu-toggle").setAttribute("aria-expanded",n.classList.contains("open"))});
document.querySelectorAll(".main-nav a").forEach(a=>a.addEventListener("click",()=>document.querySelector(".main-nav").classList.remove("open")));
document.getElementById("search-toggle").addEventListener("click",()=>{const q=prompt("Search products");if(q){const found=products.filter(p=>p.name.toLowerCase().includes(q.toLowerCase()));grid.innerHTML=found.length?found.map(productCard).join():'<p>No matching products. Try another search.</p>';document.getElementById("shop").scrollIntoView()}});
document.getElementById("year").textContent=new Date().getFullYear();
renderProducts();renderCart();
