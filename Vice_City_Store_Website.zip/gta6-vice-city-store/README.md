# Vice City Supply — HTML/CSS/JavaScript Storefront

A responsive, front-end gaming merchandise and PS5 rental storefront built with plain HTML, CSS and JavaScript. Product images were extracted from the supplied `GTA6_assets.zip`.

## Run locally
1. Extract `Vice_City_Store_Website.zip`.
2. Open `index.html` in a modern browser.
3. For best results, run a local server from this folder:
   - Python: `python -m http.server 8000`
   - Then visit `http://localhost:8000`

No build tools or package installation are required.

## Included features
- Responsive Vice City-inspired dark/neon storefront.
- Product catalogue with category filters.
- Add-to-cart, quantity count, remove item and localStorage persistence.
- PS5 rental package selector (1, 2, 4 and 8 hours).
- Booking request modal with date, time and customer fields.
- Newsletter demo form and mobile navigation.
- 79 supplied product/design images in `assets/`.

## Important: demo vs production
This is a static front-end starter, not a production e-commerce or rental platform.
- Cart checkout is a demo message only; no orders or payments are processed.
- Booking requests are displayed locally only; they are not sent to an admin.
- No stock, rental-calendar, double-booking, customer-account or order-tracking backend is included.
- Connect a backend/API, database, payment gateway (such as Razorpay), email/WhatsApp notifications and rental availability management before accepting real orders or bookings.
- Replace placeholder contact details and confirm all product names, prices, delivery terms, deposits and rental policies.
- Product prices and product descriptions are editable in `script.js` in the `products` array.

## Files
- `index.html` — page structure and content
- `styles.css` — responsive styling
- `script.js` — product catalogue, cart and demo booking interactions
- `assets/` — supplied images

## Branding / rights note
This is an independent gaming-inspired storefront concept. It is not affiliated with, endorsed by, or an official store for Rockstar Games or Sony. Use only artwork, trademarks and product imagery you have the rights to use. Do not advertise unofficial merchandise as official.
